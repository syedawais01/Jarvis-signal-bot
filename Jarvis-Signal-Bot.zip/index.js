
const { Telegraf } = require('telegraf');
const fetch = require('node-fetch');

const bot = new Telegraf('YOUR_BOT_TOKEN_HERE');

bot.start((ctx) => ctx.reply('Jarvis Activated, Boss!'));
bot.command('signal', async (ctx) => {
    const res = await fetch('https://api.coinmarketcap.com/v1/ticker/bitcoin/');
    const data = await res.json();
    ctx.reply(`Current BTC Price: $${data[0].price_usd}`);
});

bot.launch();
console.log('Jarvis is running!');
